<?php

namespace App\Livewire;

use Livewire\Component;

class WebNavbar extends Component
{
    public function render()
    {
        return view('livewire.web-navbar');
    }
}
