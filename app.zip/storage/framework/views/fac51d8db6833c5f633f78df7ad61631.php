<div class="mx-5">
    <h2 class="text-3xl font-bold my-4"><?php echo e($title); ?></h2>

    <div wire:ignore.self class="grid grid-cols-1 md:grid-cols-3 gap-8 bg-gray-200">
    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
    // remove \n from description 
        $product->description_html = str_replace('\n', '', $product->description_html);
    ?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('web-product-card', ['product' => $product]);

$__html = app('livewire')->mount($__name, $__params, 'lw-2299523482-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div>
<?php /**PATH D:\qbweb\oago\resources\views/livewire/web-product.blade.php ENDPATH**/ ?>