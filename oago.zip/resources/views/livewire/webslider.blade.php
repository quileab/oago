<?php

use Livewire\Volt\Component;

new class extends Component {
    //
}; ?>

<div>
    <div id='slider' class="z-0 transition-all duration-500" style="height: 0px;">
        <img src="{{ asset('storage/slider/slide (1).jpg') }}" loading="lazy" />
        <img src="{{ asset('storage/slider/slide (2).jpg') }}" loading="lazy" />
        <img src="{{ asset('storage/slider/slide (3).jpg') }}" Loading="lazy" />
    </div>
</div>