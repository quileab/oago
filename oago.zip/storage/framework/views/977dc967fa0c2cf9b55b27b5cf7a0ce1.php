<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, viewport-fit=cover">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<!-- Charly -->

<body class="min-h-screen font-sans antialiased bg-gray-200 text-gray-900">
    <?php if (isset($component)) { $__componentOriginal8a061809859996dc536cb3516630e4ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a061809859996dc536cb3516630e4ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.web-navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('web-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a061809859996dc536cb3516630e4ee)): ?>
<?php $attributes = $__attributesOriginal8a061809859996dc536cb3516630e4ee; ?>
<?php unset($__attributesOriginal8a061809859996dc536cb3516630e4ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a061809859996dc536cb3516630e4ee)): ?>
<?php $component = $__componentOriginal8a061809859996dc536cb3516630e4ee; ?>
<?php unset($__componentOriginal8a061809859996dc536cb3516630e4ee); ?>
<?php endif; ?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('cart', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3141453323-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('web-search-filter', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3141453323-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <div class="my-4">
        <?php if(session()->has('search')||session()->has('category')): ?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('web-product', ['title' => 'Productos Encontrados','items' => 30,'filter' => ['published' => true]]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3141453323-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <?php else: ?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('web-product', ['title' => 'Productos Destacados','items' => 3,'filter' => ['featured' => true, 'published' => true]]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3141453323-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('web-product', ['title' => 'Productos Publicados','items' => 9,'filter' => ['published' => true]]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3141453323-4', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <?php endif; ?>
    </div>
    <?php if (isset($component)) { $__componentOriginalf978ae35c4070f2ea75ad3f3b050eef4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf978ae35c4070f2ea75ad3f3b050eef4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.web-footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('web-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf978ae35c4070f2ea75ad3f3b050eef4)): ?>
<?php $attributes = $__attributesOriginalf978ae35c4070f2ea75ad3f3b050eef4; ?>
<?php unset($__attributesOriginalf978ae35c4070f2ea75ad3f3b050eef4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf978ae35c4070f2ea75ad3f3b050eef4)): ?>
<?php $component = $__componentOriginalf978ae35c4070f2ea75ad3f3b050eef4; ?>
<?php unset($__componentOriginalf978ae35c4070f2ea75ad3f3b050eef4); ?>
<?php endif; ?>
    
    <?php if (isset($component)) { $__componentOriginal2aca76be1376419dfd37220f36011753 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2aca76be1376419dfd37220f36011753 = $attributes; } ?>
<?php $component = Mary\View\Components\Toast::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('toast'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Mary\View\Components\Toast::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2aca76be1376419dfd37220f36011753)): ?>
<?php $attributes = $__attributesOriginal2aca76be1376419dfd37220f36011753; ?>
<?php unset($__attributesOriginal2aca76be1376419dfd37220f36011753); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2aca76be1376419dfd37220f36011753)): ?>
<?php $component = $__componentOriginal2aca76be1376419dfd37220f36011753; ?>
<?php unset($__componentOriginal2aca76be1376419dfd37220f36011753); ?>
<?php endif; ?>
</body>

</html><?php /**PATH C:\qb\qbweb\oago\resources\views/index.blade.php ENDPATH**/ ?>