<?php

use Livewire\Volt\Component;

?>

<div>
    <div id='slider' class="z-0 transition-all duration-500" style="height: 0px;">
        <img src="<?php echo e(asset('storage/slider/slide (1).jpg')); ?>" loading="lazy" />
        <img src="<?php echo e(asset('storage/slider/slide (2).jpg')); ?>" loading="lazy" />
        <img src="<?php echo e(asset('storage/slider/slide (3).jpg')); ?>" Loading="lazy" />
    </div>
</div><?php /**PATH C:\qb\qbweb\oago\resources\views\livewire\webslider.blade.php ENDPATH**/ ?>