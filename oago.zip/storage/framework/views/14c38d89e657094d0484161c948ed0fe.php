<div class="card bg-white shadow-xl overflow-hidden" wire:key="product-<?php echo e($product->id); ?>">
    <div class="grid grid-cols-2">
        <img class="h-32 w-auto mx-auto aspect-square" src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->category); ?>" />
        <div class="p-2 bg-slate-100">
            <h2 class="text-2xl"><?php echo e($product->brand); ?></h2>
            <p><?php echo e($product->description); ?></p>
        </div>
    </div>
    <!--[if BLOCK]><![endif]--><?php if(Auth::guest()): ?>
    <div class="p-2 bg-slate-100 text-center text-sm">
        Regístrese para ver precios o realizar compras
    </div>

    <?php else: ?>
    <div class="p-2 bg-slate-100 grid grid-cols-2">
        <div>
            <h3 class="<?php echo \Illuminate\Support\Arr::toCssClasses([ "text-2xl text-center font-bold text-green-700" , "text-xl line-through"=>
                $product->offer_price>0
                ]); ?>">$ <?php echo e(number_format($product->user_price, 2, ',', '.')); ?>

            </h3>
            <!--[if BLOCK]><![endif]--><?php if($product->offer_price>0): ?>
            <h3 class="text-2xl text-center font-bold text-green-700">$ <?php echo e(number_format($product->offer_price, 2, ',','.')); ?></h3>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div>
            <p><?php echo $product->description_html; ?></p>
            <p class="text-xs text-right">Cod. <?php echo e($product->id); ?></p>
        </div>
    </div>
    <div class="p-2 bg-slate-100 grid grid-cols-2">
        <p>
            <?php if (isset($component)) { $__componentOriginal602b228a887fab12f0012a3179e5b533 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal602b228a887fab12f0012a3179e5b533 = $attributes; } ?>
<?php $component = Mary\View\Components\Button::resolve(['label' => 'Comprar','icon' => 'o-shopping-cart'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Mary\View\Components\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn-outline text-orange-600 btn-sm','wire:click' => 'buy('.e($product).',false)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal602b228a887fab12f0012a3179e5b533)): ?>
<?php $attributes = $__attributesOriginal602b228a887fab12f0012a3179e5b533; ?>
<?php unset($__attributesOriginal602b228a887fab12f0012a3179e5b533); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal602b228a887fab12f0012a3179e5b533)): ?>
<?php $component = $__componentOriginal602b228a887fab12f0012a3179e5b533; ?>
<?php unset($__componentOriginal602b228a887fab12f0012a3179e5b533); ?>
<?php endif; ?>
        </p>
        <p>
            <?php if (isset($component)) { $__componentOriginal602b228a887fab12f0012a3179e5b533 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal602b228a887fab12f0012a3179e5b533 = $attributes; } ?>
<?php $component = Mary\View\Components\Button::resolve(['label' => 'Comprar Pack x '.e($product->qtty_package).'','icon' => 'o-shopping-cart'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Mary\View\Components\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn-outline text-orange-600 btn-sm','wire:click' => 'buy('.e($product).',true)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal602b228a887fab12f0012a3179e5b533)): ?>
<?php $attributes = $__attributesOriginal602b228a887fab12f0012a3179e5b533; ?>
<?php unset($__attributesOriginal602b228a887fab12f0012a3179e5b533); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal602b228a887fab12f0012a3179e5b533)): ?>
<?php $component = $__componentOriginal602b228a887fab12f0012a3179e5b533; ?>
<?php unset($__componentOriginal602b228a887fab12f0012a3179e5b533); ?>
<?php endif; ?>
        </p>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH C:\qb\qbweb\oago\resources\views/livewire/web-product-card.blade.php ENDPATH**/ ?>