<?php

use Livewire\Volt\Component;

?>

<div>
    //
</div><?php /**PATH C:\qb\qbweb\oago\resources\views\livewire\products\crud.blade.php ENDPATH**/ ?>