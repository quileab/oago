<?php

use Livewire\Volt\Component;
use Livewire\WithPagination;
use Livewire\WithoutUrlPagination;
use Livewire\Attributes\On;
use Mary\Traits\Toast;

?>

<div class="mx-5 z-10 bg-gray-200">
    <?php if($featured): ?>
        <h2 class="text-3xl font-bold my-4">Productos Destacados</h2>
    <?php else: ?>
        <h2 class="text-3xl font-bold my-4">Productos</h2>
    <?php endif; ?>
    <div wire:ignore.self class="grid grid-cols-1 md:grid-cols-3 gap-8">
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div>
                    <?php
                        // remove \n from description 
                        $product->description_html = str_replace('\n', '', $product->description_html);
                    ?>
                    
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('web-product-card', ['product' => $product]);

$__html = app('livewire')->mount($__name, $__params, 'prod-<?php echo e($product->id); ?>'.Str::random(16), $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h1 class="text-2xl">No existen productos</h1>
        <?php endif; ?>
    </div>
    <div class="block justify-center w-full mt-2">
        <?php echo e($products->links(data: ['scrollTo' => true])); ?>

    </div>
</div><?php /**PATH C:\qb\qbweb\oago\resources\views\livewire\webproductsmain.blade.php ENDPATH**/ ?>