<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, viewport-fit=cover">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<!-- Charly -->

<body class="flex flex-col min-h-screen font-sans antialiased bg-gray-200 text-gray-900">
  <?php if (isset($component)) { $__componentOriginal8a061809859996dc536cb3516630e4ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a061809859996dc536cb3516630e4ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.web-navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('web-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a061809859996dc536cb3516630e4ee)): ?>
<?php $attributes = $__attributesOriginal8a061809859996dc536cb3516630e4ee; ?>
<?php unset($__attributesOriginal8a061809859996dc536cb3516630e4ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a061809859996dc536cb3516630e4ee)): ?>
<?php $component = $__componentOriginal8a061809859996dc536cb3516630e4ee; ?>
<?php unset($__componentOriginal8a061809859996dc536cb3516630e4ee); ?>
<?php endif; ?>

  <div class="border-2 my-auto py-4 border-green-600 rounded bg-green-300 text-gray-950 text-2xl text-center">
    Orden enviada correctamente.
  </div>

  <?php if (isset($component)) { $__componentOriginalf978ae35c4070f2ea75ad3f3b050eef4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf978ae35c4070f2ea75ad3f3b050eef4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.web-footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('web-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf978ae35c4070f2ea75ad3f3b050eef4)): ?>
<?php $attributes = $__attributesOriginalf978ae35c4070f2ea75ad3f3b050eef4; ?>
<?php unset($__attributesOriginalf978ae35c4070f2ea75ad3f3b050eef4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf978ae35c4070f2ea75ad3f3b050eef4)): ?>
<?php $component = $__componentOriginalf978ae35c4070f2ea75ad3f3b050eef4; ?>
<?php unset($__componentOriginalf978ae35c4070f2ea75ad3f3b050eef4); ?>
<?php endif; ?>
</body>

</html>






<?php /**PATH C:\qb\qbweb\oago\resources\views\ordersuccess.blade.php ENDPATH**/ ?>